# Fantasy-Cricket-Python-Project
It is an online game where you create a virtual team of real cricket players and score points  depending on how your chosen players perform in real life matches. To win a tournament,  you must try and get the maximum points and the No. 1 rank amongst other participants.

<img src="screenshot.png"/>
